A Pen created at CodePen.io. You can find this one at https://codepen.io/ipang-dwi/pen/XBzzpQ.

 Made with particles.js, a lightweight JavaScript library for creating particles