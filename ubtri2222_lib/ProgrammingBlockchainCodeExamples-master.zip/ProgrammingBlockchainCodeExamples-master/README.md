# Programming The Blockchain in C*#*
**Talk is cheap, show me the code!**

1. Clone
2. Open solution
3. Choose and set a startup project
4. Build and run!

## [Click here to read the book](https://programmingblockchain.gitbooks.io/programmingblockchain/content/)

## Links

[The book on GitHub](https://github.com/ProgrammingBlockchain/ProgrammingBlockchain)  
[The book on GitBook](https://www.gitbook.com/book/programmingblockchain/programmingblockchain) (You can download pdf, epub, mobi versions here.)  
[Code examples on GitHub](https://github.com/ProgrammingBlockchain/ProgrammingBlockchainCodeExamples/)  
[Hall of the Makers](http://n.bitcoin.ninja/) (Here are the true makers those succeeded to complete the challenges of this book.)
