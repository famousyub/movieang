﻿namespace Com.Innoq.SharpestChain.Eventing
{
    public partial class ConnectionHandler
    {
        private sealed class CheckConnection
        {
        }

        private sealed class HeartBeat
        {
        }

        private sealed class Replay
        {
        }
    }
}
