﻿namespace Com.Innoq.SharpestChain.Controllers
{
    public class TransactionDto
    {
        public string payload { get; set; }
    }
}
