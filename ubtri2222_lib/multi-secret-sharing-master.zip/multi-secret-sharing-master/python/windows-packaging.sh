pyinstaller --windowed --onefile --path C:\Python35\Lib\site-packages\PyQt5\Qt\bin ui_controller.py
