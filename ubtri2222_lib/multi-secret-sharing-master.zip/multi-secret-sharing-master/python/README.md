### Python Prototype TODO

- [x] public API and hidden methods
- [x] Move helper functions to a ProbabilityHelper class
- [x] Discuss research reasons
- [x] Do a generation of shares for all users at once
- [x] GUI in Qt Designer before going to C++
- [x] Calculate f polynomial value to have B
- [x] check why v, u = 2 while q,i size = 1 
