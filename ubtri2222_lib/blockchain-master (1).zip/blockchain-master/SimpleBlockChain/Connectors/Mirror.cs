﻿using System;

namespace SimpleBlockChain.Connectors
{
    public class Mirror
    {
        
    }

}
